import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; 
import { AppComponent } from './app.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { TodolistDashboardComponent } from './todolist-dashboard/todolist-dashboard.component';
import { RouterModule, Routes} from '@angular/router';
import { AuthUsersService } from './auth-users.service';
import { AuthGuardGuard } from './auth-guard.guard';
import { TodoServiceService } from './todo-service.service';


const appRoutes: Routes = [
  { path: '', component: LoginpageComponent },
  { path: 'todo-list-dashboard', canActivate: [AuthGuardGuard], component: TodolistDashboardComponent }
];


@NgModule({
  declarations: [
    AppComponent,
    LoginpageComponent,
    TodolistDashboardComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
  ],
  providers: [AuthUsersService,AuthGuardGuard,TodoServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
