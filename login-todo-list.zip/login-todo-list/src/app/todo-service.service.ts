import { Injectable } from '@angular/core';
import { Todo } from './classes/todo';


@Injectable()
export class TodoServiceService {

  public todos: Todo[];
  public nextId: number;

  constructor() { 

    this.todos = [
      new Todo(0, 'This is first todo'),
      new Todo(1, 'This is second todo'),
      new Todo(2, 'This is the third todo'),

    ];

    this.nextId = 3;
  }

  public addTodo(name: string): void{
    let todo = new Todo(this.nextId, name);
    this.todos.push(todo);
    this.nextId++
  }

  public getTodos(): Todo[]{
    return this.todos;
  }

  public removeTodo(id: number): void {
  
    this.todos = this.todos.filter((todo) => todo.id !== id)
   
  }
}
