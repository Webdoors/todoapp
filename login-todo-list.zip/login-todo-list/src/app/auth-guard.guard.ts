import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthUsersService } from './auth-users.service';



@Injectable()
export class AuthGuardGuard implements CanActivate {

  constructor(private user: AuthUsersService){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return this.user.getUserIsLoggedIn();
  }
}
