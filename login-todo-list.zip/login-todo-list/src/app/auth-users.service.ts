import { Injectable } from '@angular/core';

@Injectable()
export class AuthUsersService {

  private isUserLoggedIn;
  private username;
  constructor() { 
    this.isUserLoggedIn = false
  }

  setUserLoggedIn(){
    this.isUserLoggedIn = true;
  }

  getUserIsLoggedIn(){
    return this.isUserLoggedIn;
  }

}
