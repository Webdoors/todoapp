import { Component, OnInit, Input } from '@angular/core';
import { AuthUsersService } from '../auth-users.service';
import { Todo } from '../classes/todo';
import { TodoServiceService } from '../todo-service.service';

@Component({
  selector: 'app-todolist-dashboard',
  templateUrl: './todolist-dashboard.component.html',
  styleUrls: ['./todolist-dashboard.component.css']
})
export class TodolistDashboardComponent implements OnInit {

  @Input() private todo: Todo;
  private todos: Todo; 
  

  private todoText: string;
  
  constructor(private user: AuthUsersService, private todoService: TodoServiceService) { 
    this.todoText = '';
  }

  ngOnInit() {
  }


  private addTodo(): void{
    this.todoService.addTodo(this.todoText);
    console.log("Todo: ", this.todoText);
    this.todoText = "";
  }

  private removeTodo(): void{
    this.todoService.removeTodo(this.todos.id);
  }

}
