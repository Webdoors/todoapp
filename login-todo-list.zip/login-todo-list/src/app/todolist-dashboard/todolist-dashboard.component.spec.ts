import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TodolistDashboardComponent } from './todolist-dashboard.component';

describe('TodolistDashboardComponent', () => {
  let component: TodolistDashboardComponent;
  let fixture: ComponentFixture<TodolistDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TodolistDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TodolistDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
